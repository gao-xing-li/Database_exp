/* =========================================================
   03_crud.sql

   CRUD ��ʾ��
   1. ��Ʒ
   2. ���
   3. ���۶�����������ϸ

   ִ��ǰ��
   00_create_database.sql
   01_create_tables.sql
   02_insert_sample_data.sql
   ========================================================= */

USE AnimeGoodsStoreDB;
GO


/* =========================================================
   ��һ���֣���Ʒ���� CRUD
   ========================================================= */


/* ---------------------------------------------------------
   C = CREATE / INSERT

   ����һ��������Ʒ
   --------------------------------------------------------- */

INSERT INTO dbo.Product
(
    product_id,
    product_code,
    product_name,
    category_id,
    ip_id,
    character_id,
    sale_price,
    product_status
)
VALUES
(
    9001,
    'P_TEST',
    N'CRUD������Ʒ',
    1,
    NULL,
    NULL,
    20.00,
    'ON_SALE'
);
GO


/* Ϊ����Ʒ��������¼ */

INSERT INTO dbo.Inventory
(
    product_id,
    on_hand_qty,
    reserved_qty,
    reorder_point
)
VALUES
(
    9001,
    10,
    0,
    3
);
GO


/* ---------------------------------------------------------
   R = READ / SELECT
   --------------------------------------------------------- */

SELECT
    p.product_id,
    p.product_code,
    p.product_name,
    p.sale_price,
    p.product_status,
    i.on_hand_qty,
    i.reserved_qty,
    i.on_hand_qty - i.reserved_qty AS available_qty,
    i.reorder_point
FROM dbo.Product AS p
JOIN dbo.Inventory AS i
    ON p.product_id = i.product_id
WHERE p.product_id = 9001;
GO


/* ---------------------------------------------------------
   U = UPDATE

   �޸�ǰ��ʹ����ͬ WHERE �������� SELECT��
   --------------------------------------------------------- */

SELECT *
FROM dbo.Product
WHERE product_id = 9001;
GO


UPDATE dbo.Product
SET
    sale_price = 22.00,
    product_name = N'CRUD������Ʒ���޸ĺ�'
WHERE product_id = 9001;
GO


SELECT *
FROM dbo.Product
WHERE product_id = 9001;
GO


/* ������ */

SELECT *
FROM dbo.Inventory
WHERE product_id = 9001;
GO


UPDATE dbo.Inventory
SET
    on_hand_qty = 15,
    reorder_point = 5,
    updated_at = SYSDATETIME()
WHERE product_id = 9001;
GO


SELECT
    *,
    on_hand_qty - reserved_qty AS available_qty
FROM dbo.Inventory
WHERE product_id = 9001;
GO


/* ---------------------------------------------------------
   D = DELETE

   Product �� Inventory ���ã���˲���ֱ����ɾ Product��
   ��ȷ�ϴ�ɾ�����ݡ�
   --------------------------------------------------------- */

SELECT *
FROM dbo.Inventory
WHERE product_id = 9001;

SELECT *
FROM dbo.Product
WHERE product_id = 9001;
GO


/* ��ɾ���ӱ� */

DELETE FROM dbo.Inventory
WHERE product_id = 9001;
GO


/* ��ɾ������ */

DELETE FROM dbo.Product
WHERE product_id = 9001;
GO


/* ȷ���Ѿ�ɾ�� */

SELECT *
FROM dbo.Product
WHERE product_id = 9001;

SELECT *
FROM dbo.Inventory
WHERE product_id = 9001;
GO



/* =========================================================
   �ڶ����֣����۶��� CRUD
   ========================================================= */


/* ---------------------------------------------------------
   C = CREATE

   ����һ����ͨ�ֻ����Զ�����
   --------------------------------------------------------- */

INSERT INTO dbo.SalesOrder
(
    order_id,
    order_no,
    order_type,
    member_id,
    cashier_id,
    reservation_id,
    order_time,
    order_status
)
VALUES
(
    9001,
    'SO_TEST',
    'SPOT',
    NULL,
    1,
    NULL,
    NULL,
    'CREATED'
);
GO


/* ���Ӷ�����ϸ */

INSERT INTO dbo.SalesOrderItem
(
    order_id,
    product_id,
    quantity,
    unit_price
)
VALUES
(
    9001,
    1,
    1,
    68.00
);
GO


/* ---------------------------------------------------------
   R = READ

   ������ѯ��ʲ��Զ�����
   --------------------------------------------------------- */

SELECT
    so.order_id,
    so.order_no,
    so.order_type,
    so.order_status,
    p.product_name,
    soi.quantity,
    soi.unit_price,
    soi.quantity * soi.unit_price AS item_amount
FROM dbo.SalesOrder AS so
JOIN dbo.SalesOrderItem AS soi
    ON so.order_id = soi.order_id
JOIN dbo.Product AS p
    ON soi.product_id = p.product_id
WHERE so.order_id = 9001;
GO


/* ---------------------------------------------------------
   U = UPDATE

   �ڶ������ǰ���޸Ĳ�ȷ�϶�����ϸ��
   --------------------------------------------------------- */

SELECT *
FROM dbo.SalesOrderItem
WHERE order_id = 9001
  AND product_id = 1;
GO


UPDATE dbo.SalesOrderItem
SET quantity = 2
WHERE order_id = 9001
  AND product_id = 1;
GO


SELECT
    order_id,
    product_id,
    quantity,
    unit_price,
    quantity * unit_price AS item_amount
FROM dbo.SalesOrderItem
WHERE order_id = 9001
  AND product_id = 1;
GO


/* ȷ����ϸ�󣬽������� CREATED ��Ϊ COMPLETED */

SELECT *
FROM dbo.SalesOrder
WHERE order_id = 9001;
GO


UPDATE dbo.SalesOrder
SET
    order_status = 'COMPLETED',
    order_time = SYSDATETIME()
WHERE order_id = 9001;
GO


SELECT *
FROM dbo.SalesOrder
WHERE order_id = 9001;
GO


/* ---------------------------------------------------------
   D = DELETE

   SalesOrderItem ������ SalesOrder��
   ������Ȼ�����ӱ� �� ����˳��ɾ����
   --------------------------------------------------------- */

SELECT *
FROM dbo.SalesOrderItem
WHERE order_id = 9001;

SELECT *
FROM dbo.SalesOrder
WHERE order_id = 9001;
GO


DELETE FROM dbo.SalesOrderItem
WHERE order_id = 9001;
GO


DELETE FROM dbo.SalesOrder
WHERE order_id = 9001;
GO


/* ������֤ */

SELECT *
FROM dbo.SalesOrder
WHERE order_id = 9001;

SELECT *
FROM dbo.SalesOrderItem
WHERE order_id = 9001;
GO